# import the necessary packages
from motiondetector import MotionDetector